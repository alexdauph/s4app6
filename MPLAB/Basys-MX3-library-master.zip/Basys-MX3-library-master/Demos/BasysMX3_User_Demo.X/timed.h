

#ifndef _TIMED_H    /* Guard against multiple inclusion */
#define _TIMED_H

unsigned char VisCtrlsTest(void);
unsigned char RecPlayTest(char *szMsg);
unsigned char BeepTest(char *szMsg);

#endif /* _TIMED_H */

/* *****************************************************************************
 End of File
 */
